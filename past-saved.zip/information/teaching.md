* Writing Guidance, S'20
* Introduction to Cyberspace Security, S'20
* Basics of Wireless and IoT Security, Zhejiang University, F'18, F'19
* Wireless and IoT Security, Zhejiang University, S'18

---

* CSE 241 Digital Systems, [S'13](http://www.buffalo.edu/~kuiren/courses/CSE241.html) 
* CSE 664 Applied Cryptography and Computer Security, [S'14, S'15](http://www.acsu.buffalo.edu/~kuiren/courses/CSE664_Syllabus.pdf) 
* CSE 566 Wireless Network Security, S’17
* CSE 706 Seminar: Security and Privacy in Internet of Things, F'16
* CSE 706 Seminar: Selected Topics in Privacy and Security, F'15
* CSE 706 Seminar: Sensing, Crowdsourcing with Smartphones and Wearable Devices, [F'14](http://www.cse.buffalo.edu/shared/course_instance.php?semester=201409&classnumber=12388) 
* CSE 706 Seminar: Security and Privacy in Emerging Applications F'13 
* CSE 706 Seminar: Advanced Topics on Privacy Enhancing Technologies, F'12 


---

- IIT-ECE 443 Introduction to Computer Security, F'11 
- IIT-ECE 543 Computer Network Security, F'07, S'08, F'09, F'10, S'12 
- IIT-ECE 546 Wireless Security, F'08, S'10, F'09, S'11 