* Test of Time Paper Award, 2020 IEEE INFOCOM (paper published in the 2010 proceedings of the IEEE International Conference on Computer Communications), Jan. 20, 2020.
* Best Paper Award, 2019 IEEE Global Communications Conference (GLOBECOM), Hawaii, USA, Dec. 9-13, 2019.
* Highly Cited Researchers of the Year Award, 2019
* Best Paper Award, the 24th International Conference on Parallel and Distributed Systems(ICPADS'18), Sentosa, Singapore, Dec. 11-13, 2018
* Best Paper Award, ChinaCrypt'18, Sichuan, China, Oct. 26-28, 2018
* Best Paper Award, the 13th ACM ASIA Conference on Computer and Communications Security(AsiaCCS'18), Songdo, Korea, Jun. 4–8, 2018
* SUNY Empire Innovation Professor, University at Buffalo, State University of New York, 2017
* Best Paper Award, IEEE/ACM International Symposium on Quality of Service (IWQoS'17), Vilanova, Barcelona, Spain, June 14-16, 2017
* Best Student Paper Award, The 37th IEEE International Conference on Distributed Computing Systems (ICDCS'17), Atlanta, GA, June 5-8, 2017
* Technical Recognition Award, IEEE Communications & Information Security Technical Committee (CISTC), 2017
* Exceptional Scholar Award for Sustained Achievement, State University of New York, Buffalo, 2016
* Fellow of IEEE (elevated within 8 years after his Ph.D, one of the quickest in IEEE history), 2015
* SEAS Senior Researcher of the Year Award, SUNY Buffalo, 2015
* Distinguished Lecturer, IEEE Vehicular Technology Society, 2014
* Member of Academic Advisory Committee, School of Computer Science and Technology, Shandong University, China, since 2014
* Early Promotion to Associate Professor with Tenure, Dept. of ECE, Illinois Institute of Technology, 2012 
* Sigma Xi Research Excellence Award (Junior Faculty Category), Illinois Institute of Technology, 2012 
* National Science Foundation Faculty Early Career Development (CAREER) Award, 2011 
* Best Paper Award, the 19th IEEE International Conference on Network Protocols (ICNP'11), Vancouver, BC, Canada, Oct. 17-20, 2011 
* Board Member, Internet Privacy Task Force, State of Illinois (Appointed by Then-Governor Pat Quinn), 2011-2012 
* Best Paper Award, the 4th International ICST Conference on Communications and Networking in China (Chinacom'09), Xi'an, China, Aug. 26-28, 2009 
* Best Paper Award, International Conference on Wireless Algorithms, Systems, and Applications (WASA'06), Xi'an, China, Aug. 15-18, 2006


<!-- This is for honors -->